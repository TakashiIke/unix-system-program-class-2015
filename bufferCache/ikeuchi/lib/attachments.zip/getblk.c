#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "getblk.h"
#include "buf.h"
#include "dlist.h"
#include "state.h"
//============================
/*
void brelse(buf *buffer);
buf *Search(int blkno);
int IsStatus(buf *buffer, int state);
void AddStatus(buf *buffer, int state);
void RemFromFreeList(buf *buf);
buf *GetBufFromFreeList(buf *F_LIST);
void AddToHash(buf *elem);

int IsInFreeList(buf *buffer);
int CheckStatus(buf *buffer, int state);
void RemStatus(buf *buffer, int state);
void MakeStatus(buf *buffer, int state);
*/
//============================
buf *getblk(int blknum){
  while(&h_head[blknum % 4] != NULL){
    buf *buffer = Search(blknum);
    if(buffer != NULL){
      assert(buffer != NULL);
      if(!IsStatus(buffer, STAT_LOCKED)){
	//scenario 5
	//sleep();
	printf("Process goes to sleep\n");
	return NULL;
	continue;
      }
      //scenario 1
      MakeStatus(buffer, (STAT_LOCKED | STAT_VALID));
      RemFromFreeList(buffer);
      return buffer;	
    }
    else{
      if(IsInFreeList(buffer)){
	//scenario 4
	//sleep();
	printf("Process goes to sleep\n");
	continue;
      }
      //scenario 3
      RemFromFreeList(buffer);
      if(CheckStatus(buffer, STAT_DWR)){
	//asynchronous write buffer to disk;
	continue;
      }
      //scenario 2
      buf *elem = GetBufFromFreeList(&f_head);
      RemStatus(buffer, STAT_VALID);
      elem -> blkno = blknum;
      AddToHash(elem);
      /*
      printf("Kernel HDD access occuring\n");
      AddStatus(buffer, STAT_KRDWR);
      printf("Kernel HDD access finihe\n");
      RemStatus(buffer, STAT_KRDWR);
      AddStatus(buffer, STAT_VALID);
      */
      return elem;
    }
  }
  printf("BUFFER NOT FOUND\n");
  return NULL;
}

void brelse(buf *buffer){
  //wakeup();
  printf("Wakeup processes wating for any buffer\n");
  if(CheckStatus(buffer, STAT_LOCKED | STAT_VALID | STAT_WAITED)){
    //wakeup();
    printf("Wakeup processes waiting for buffer of blkno %d\n", buffer -> blkno);
  }
  //raise_cpu_level();
  if(CheckStatus(buffer, STAT_VALID) & !CheckStatus(buffer, STAT_OLD)){
    insert_list(&f_head, buffer, FREETAIL);
  }
  else{
    insert_list(&f_head, buffer, FREEHEAD);
  }
  //lower_cpu_level();
}


// based on the blkno, search the hash key, and 
// if there exist the value in the hash list, return 
// the buffer that contains blkno, return NULL otherwise
buf *Search(int blkno){
  int hkey = blkno % 4;
  buf *p;
  for(p = h_head[hkey].hash_fp; p != &h_head[hkey]; p = p -> hash_fp){
    if(p -> blkno == blkno){
      return p;
    }
    return NULL;
  }
}

//
//int IsInHash(int blkno){
//  
//}

// check wheather buffer is locked or not
// take & with STAT_LOCKED and see the bit level operation
int IsStatus(buf *buffer, int state){
  return (buffer -> stat & state);
}
void AddStatus(buf *buffer, int state){
  (buffer -> stat) | state;
}
//// add STAT_LOCKED to the status of buffer  
//void Lock(buf *buffer){
//  buffer -> stat | STAT_LOCKED;
//}

void RemFromFreeList(buf *buffer){
  buf *prev = buffer -> free_bp;
  buf *next = buffer -> free_fp;
  prev -> free_fp = next;
  next -> free_bp = prev;
  buffer -> free_fp = NULL;
  buffer -> free_bp = NULL;
}

buf *GetBufFromFreeList(buf *F_LIST){
  buf *buffer = F_LIST -> free_fp;
  if(!CheckStatus(buffer, STAT_DWR)){
    RemFromFreeList(buffer);
    return buffer;
  }
  else{
    GetBufFromFreeList(buffer);
  }
}

void AddToHash(buf *elem){
  int key = elem -> blkno;
  int hkey = key % 4;
  AddStatus(elem, STAT_LOCKED);
  insert_hash_tail(&h_head[hkey], elem);
}

int IsInFreeList(buf *buffer){
  if(buffer -> free_fp == NULL){
    return 0;
  }
  return 1;
}

void MakeStatus(buf *buffer, int state){
  buffer -> stat = state;
}

int CheckStatus(buf *buffer, int state){
  return (buffer -> stat & state);
}

void RemStatus(buf *buffer, int state){
  buffer -> stat ^ state;
}
